package io.armi.netheroreoverlay.data;

import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;

public record OreMarker(
	OreType type,
	int x,
	int y,
	int z,
	OptionalDouble distance,
	OptionalInt clusterSize,
	Map<String, String> metadata
) {
	public OreMarker {
		if (type == null) {
			throw new IllegalArgumentException("type cannot be null");
		}

		distance = distance == null ? OptionalDouble.empty() : distance;
		clusterSize = clusterSize == null ? OptionalInt.empty() : clusterSize;
		metadata = metadata == null ? Map.of() : Map.copyOf(metadata);
	}

	public int chunkX() {
		return Math.floorDiv(x, 16);
	}

	public int chunkZ() {
		return Math.floorDiv(z, 16);
	}

	public double distanceToSqr(double otherX, double otherY, double otherZ) {
		double centerX = x + 0.5d;
		double centerY = y + 0.5d;
		double centerZ = z + 0.5d;
		double deltaX = centerX - otherX;
		double deltaY = centerY - otherY;
		double deltaZ = centerZ - otherZ;
		return deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ;
	}

	public double horizontalDistanceToSqr(double otherX, double otherZ) {
		double centerX = x + 0.5d;
		double centerZ = z + 0.5d;
		double deltaX = centerX - otherX;
		double deltaZ = centerZ - otherZ;
		return deltaX * deltaX + deltaZ * deltaZ;
	}
}
