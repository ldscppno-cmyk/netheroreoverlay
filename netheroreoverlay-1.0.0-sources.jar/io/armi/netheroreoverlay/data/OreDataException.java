package io.armi.netheroreoverlay.data;

public final class OreDataException extends Exception {
	public OreDataException(String message) {
		super(message);
	}

	public OreDataException(String message, Throwable cause) {
		super(message, cause);
	}
}
