package io.armi.netheroreoverlay.data;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum OreType {
	QUARTZ("quartz", 1.00f, 1.00f, 1.00f, 0.68f),
	GOLD("gold", 1.00f, 0.85f, 0.15f, 0.68f),
	ANCIENT_DEBRIS("ancient_debris", 0.15f, 1.00f, 0.15f, 0.60f);

	private static final Map<String, OreType> BY_ID = Arrays.stream(values())
		.collect(Collectors.toUnmodifiableMap(OreType::id, Function.identity()));

	private final String id;
	private final float red;
	private final float green;
	private final float blue;
	private final float alpha;

	OreType(String id, float red, float green, float blue, float alpha) {
		this.id = id;
		this.red = red;
		this.green = green;
		this.blue = blue;
		this.alpha = alpha;
	}

	public String id() {
		return id;
	}

	public float red() {
		return red;
	}

	public float green() {
		return green;
	}

	public float blue() {
		return blue;
	}

	public float alpha() {
		return alpha;
	}

	public static Optional<OreType> fromId(String id) {
		if (id == null) {
			return Optional.empty();
		}

		return Optional.ofNullable(BY_ID.get(id.toLowerCase(Locale.ROOT)));
	}
}
