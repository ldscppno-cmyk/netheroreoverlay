package io.armi.netheroreoverlay.data;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import net.fabricmc.loader.api.FabricLoader;

public final class OreDataLoader {
	private static final Set<String> ROOT_FIELDS = Set.of("dimension", "source", "seed", "version", "ores");
	private static final Set<String> ORE_FIELDS = Set.of("x", "y", "z", "type", "distance", "clusterSize", "metadata");
	private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();

	private final Path configPath;

	public OreDataLoader() {
		this(FabricLoader.getInstance().getConfigDir().resolve("netheroreoverlay").resolve("ores.json"));
	}

	public OreDataLoader(Path configPath) {
		this.configPath = configPath;
	}

	public Path getConfigPath() {
		return configPath;
	}

	public boolean dataFileExists() {
		return Files.exists(configPath);
	}

	public OreDataset load() throws OreDataException {
		if (!dataFileExists()) {
			return OreDataset.empty();
		}

		try (Reader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
			JsonElement root = JsonParser.parseReader(reader);
			if (!root.isJsonObject()) {
				throw new OreDataException("Root JSON value must be an object");
			}

			JsonObject rootObject = root.getAsJsonObject();
			validateFields(rootObject, ROOT_FIELDS, "root");

			String dimension = readRequiredString(rootObject, "dimension", "root");
			String source = readRequiredString(rootObject, "source", "root");
			String seed = readRequiredString(rootObject, "seed", "root");
			String version = readRequiredString(rootObject, "version", "root");
			JsonArray oresArray = readRequiredArray(rootObject, "ores", "root");

			List<OreMarker> markers = new ArrayList<>(oresArray.size());
			for (int index = 0; index < oresArray.size(); index++) {
				JsonElement entry = oresArray.get(index);
				if (!entry.isJsonObject()) {
					throw new OreDataException("ore[" + index + "] must be an object");
				}

				markers.add(parseMarker(entry.getAsJsonObject(), index));
			}

			return new OreDataset(dimension, source, seed, version, markers);
		} catch (IOException exception) {
			throw new OreDataException("Failed to read " + configPath + ": " + exception.getMessage(), exception);
		} catch (JsonParseException exception) {
			throw new OreDataException("Invalid JSON in " + configPath + ": " + exception.getMessage(), exception);
		}
	}

	public void write(OreDataset dataset) throws OreDataException {
		JsonObject root = new JsonObject();
		root.addProperty("dimension", dataset.dimension());
		root.addProperty("source", dataset.source());
		root.addProperty("seed", dataset.seed());
		root.addProperty("version", dataset.version());

		JsonArray ores = new JsonArray();
		for (OreMarker marker : dataset.ores()) {
			JsonObject object = new JsonObject();
			object.addProperty("x", marker.x());
			object.addProperty("y", marker.y());
			object.addProperty("z", marker.z());
			object.addProperty("type", marker.type().id());
			marker.distance().ifPresent(value -> object.addProperty("distance", value));
			marker.clusterSize().ifPresent(value -> object.addProperty("clusterSize", value));
			if (!marker.metadata().isEmpty()) {
				JsonObject metadata = new JsonObject();
				for (Map.Entry<String, String> entry : marker.metadata().entrySet()) {
					metadata.addProperty(entry.getKey(), entry.getValue());
				}
				object.add("metadata", metadata);
			}
			ores.add(object);
		}

		root.add("ores", ores);

		try {
			Files.createDirectories(configPath.getParent());
			try (Writer writer = Files.newBufferedWriter(configPath, StandardCharsets.UTF_8)) {
				GSON.toJson(root, writer);
			}
		} catch (IOException exception) {
			throw new OreDataException("Failed to write " + configPath + ": " + exception.getMessage(), exception);
		}
	}

	private OreMarker parseMarker(JsonObject object, int index) throws OreDataException {
		String location = "ore[" + index + "]";
		validateFields(object, ORE_FIELDS, location);

		String typeId = readRequiredString(object, "type", location);
		OreType type = OreType.fromId(typeId)
			.orElseThrow(() -> new OreDataException(location + ".type has unsupported value '" + typeId + "'"));

		int x = readRequiredInt(object, "x", location);
		int y = readRequiredInt(object, "y", location);
		int z = readRequiredInt(object, "z", location);
		OptionalDouble distance = readOptionalDouble(object, "distance", location);
		OptionalInt clusterSize = readOptionalInt(object, "clusterSize", location);
		Map<String, String> metadata = readOptionalMetadata(object, "metadata", location);

		return new OreMarker(type, x, y, z, distance, clusterSize, metadata);
	}

	private void validateFields(JsonObject object, Set<String> allowedFields, String location) throws OreDataException {
		for (String key : object.keySet()) {
			if (!allowedFields.contains(key)) {
				throw new OreDataException(location + " has unsupported field '" + key + "'");
			}
		}
	}

	private JsonArray readRequiredArray(JsonObject object, String field, String location) throws OreDataException {
		JsonElement element = object.get(field);
		if (element == null || !element.isJsonArray()) {
			throw new OreDataException(location + "." + field + " must be an array");
		}

		return element.getAsJsonArray();
	}

	private String readRequiredString(JsonObject object, String field, String location) throws OreDataException {
		JsonPrimitive primitive = readRequiredPrimitive(object, field, location);
		if (!primitive.isString()) {
			throw new OreDataException(location + "." + field + " must be a string");
		}

		String value = primitive.getAsString();
		if (value.isBlank()) {
			throw new OreDataException(location + "." + field + " must not be blank");
		}

		return value;
	}

	private int readRequiredInt(JsonObject object, String field, String location) throws OreDataException {
		JsonPrimitive primitive = readRequiredPrimitive(object, field, location);
		if (!primitive.isNumber()) {
			throw new OreDataException(location + "." + field + " must be an integer");
		}

		double value = primitive.getAsDouble();
		if (!Double.isFinite(value) || value != Math.rint(value)) {
			throw new OreDataException(location + "." + field + " must be an integer");
		}

		return (int) value;
	}

	private OptionalInt readOptionalInt(JsonObject object, String field, String location) throws OreDataException {
		JsonElement element = object.get(field);
		if (element == null || element.isJsonNull()) {
			return OptionalInt.empty();
		}

		if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
			throw new OreDataException(location + "." + field + " must be an integer");
		}

		double value = element.getAsDouble();
		if (!Double.isFinite(value) || value != Math.rint(value)) {
			throw new OreDataException(location + "." + field + " must be an integer");
		}

		return OptionalInt.of((int) value);
	}

	private OptionalDouble readOptionalDouble(JsonObject object, String field, String location) throws OreDataException {
		JsonElement element = object.get(field);
		if (element == null || element.isJsonNull()) {
			return OptionalDouble.empty();
		}

		if (!element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
			throw new OreDataException(location + "." + field + " must be a number");
		}

		double value = element.getAsDouble();
		if (!Double.isFinite(value)) {
			throw new OreDataException(location + "." + field + " must be finite");
		}

		return OptionalDouble.of(value);
	}

	private Map<String, String> readOptionalMetadata(JsonObject object, String field, String location) throws OreDataException {
		JsonElement element = object.get(field);
		if (element == null || element.isJsonNull()) {
			return Map.of();
		}

		if (!element.isJsonObject()) {
			throw new OreDataException(location + "." + field + " must be an object");
		}

		Map<String, String> metadata = new LinkedHashMap<>();
		for (Map.Entry<String, JsonElement> entry : element.getAsJsonObject().entrySet()) {
			JsonElement value = entry.getValue();
			if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
				throw new OreDataException(location + "." + field + "." + entry.getKey() + " must be a string");
			}

			metadata.put(entry.getKey(), value.getAsString());
		}

		return metadata;
	}

	private JsonPrimitive readRequiredPrimitive(JsonObject object, String field, String location) throws OreDataException {
		JsonElement element = object.get(field);
		if (element == null || !element.isJsonPrimitive()) {
			throw new OreDataException(location + "." + field + " is missing or invalid");
		}

		return element.getAsJsonPrimitive();
	}
}
