package io.armi.netheroreoverlay.data;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.armi.netheroreoverlay.NetherOreOverlay;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;

public final class HiddenMarkerStateStore {
	private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();

	private final Path path;
	private final Map<String, HiddenDatasetState> hiddenByDatasetKey = new LinkedHashMap<>();

	public HiddenMarkerStateStore() {
		this(FabricLoader.getInstance().getConfigDir().resolve("netheroreoverlay").resolve("hidden-markers.json"));
	}

	public HiddenMarkerStateStore(Path path) {
		this.path = path;
		load();
	}

	public Path getPath() {
		return path;
	}

	public OreDataset apply(OreDataset dataset) {
		if (!hasIdentity(dataset) || dataset.ores().isEmpty()) {
			return dataset;
		}

		HiddenDatasetState hiddenState = hiddenByDatasetKey.get(datasetKey(dataset));
		if (hiddenState == null || hiddenState.hiddenPositions().isEmpty()) {
			return dataset;
		}

		List<OreMarker> visibleMarkers = new ArrayList<>(dataset.ores().size());
		for (OreMarker marker : dataset.ores()) {
			if (!hiddenState.hiddenPositions().contains(positionKey(marker.x(), marker.y(), marker.z()))) {
				visibleMarkers.add(marker);
			}
		}

		if (visibleMarkers.size() == dataset.ores().size()) {
			return dataset;
		}

		return new OreDataset(dataset.dimension(), dataset.source(), dataset.seed(), dataset.version(), visibleMarkers);
	}

	public void hide(OreDataset dataset, class_2338 pos) throws OreDataException {
		if (!hasIdentity(dataset)) {
			return;
		}

		String key = datasetKey(dataset);
		HiddenDatasetState current = hiddenByDatasetKey.get(key);
		LinkedHashSet<String> hiddenPositions = current == null
			? new LinkedHashSet<>()
			: new LinkedHashSet<>(current.hiddenPositions());
		if (!hiddenPositions.add(positionKey(pos))) {
			return;
		}

		hiddenByDatasetKey.put(key, new HiddenDatasetState(dataset.dimension(), dataset.source(), dataset.seed(), dataset.version(), hiddenPositions));
		save();
	}

	public int reset(OreDataset dataset) throws OreDataException {
		if (!hasIdentity(dataset)) {
			return 0;
		}

		HiddenDatasetState removed = hiddenByDatasetKey.remove(datasetKey(dataset));
		if (removed == null) {
			return 0;
		}

		save();
		return removed.hiddenPositions().size();
	}

	private void load() {
		hiddenByDatasetKey.clear();
		if (!Files.exists(path)) {
			return;
		}

		try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			JsonElement root = JsonParser.parseReader(reader);
			if (!root.isJsonObject()) {
				return;
			}

			JsonElement datasetsElement = root.getAsJsonObject().get("datasets");
			if (datasetsElement == null || !datasetsElement.isJsonArray()) {
				return;
			}

			for (JsonElement entryElement : datasetsElement.getAsJsonArray()) {
				if (!entryElement.isJsonObject()) {
					continue;
				}

				JsonObject object = entryElement.getAsJsonObject();
				String dimension = readString(object, "dimension");
				String source = readString(object, "source");
				String seed = readString(object, "seed");
				String version = readString(object, "version");
				if (dimension.isBlank() || seed.isBlank() || version.isBlank()) {
					continue;
				}

				JsonElement hiddenElement = object.get("hidden");
				if (hiddenElement == null || !hiddenElement.isJsonArray()) {
					continue;
				}

				LinkedHashSet<String> hiddenPositions = new LinkedHashSet<>();
				for (JsonElement hiddenPosElement : hiddenElement.getAsJsonArray()) {
					if (!hiddenPosElement.isJsonObject()) {
						continue;
					}

					JsonObject hiddenPos = hiddenPosElement.getAsJsonObject();
					Integer x = readInt(hiddenPos, "x");
					Integer y = readInt(hiddenPos, "y");
					Integer z = readInt(hiddenPos, "z");
					if (x == null || y == null || z == null) {
						continue;
					}

					hiddenPositions.add(positionKey(x, y, z));
				}

				if (!hiddenPositions.isEmpty()) {
					HiddenDatasetState state = new HiddenDatasetState(dimension, source, seed, version, hiddenPositions);
					hiddenByDatasetKey.put(datasetKey(state), state);
				}
			}
		} catch (Exception exception) {
			NetherOreOverlay.LOGGER.warn("Failed to load hidden marker state from {}", path, exception);
			hiddenByDatasetKey.clear();
		}
	}

	private void save() throws OreDataException {
		JsonObject root = new JsonObject();
		JsonArray datasets = new JsonArray();
		for (HiddenDatasetState state : hiddenByDatasetKey.values()) {
			if (state.hiddenPositions().isEmpty()) {
				continue;
			}

			JsonObject object = new JsonObject();
			object.addProperty("dimension", state.dimension());
			object.addProperty("source", state.source());
			object.addProperty("seed", state.seed());
			object.addProperty("version", state.version());

			JsonArray hidden = new JsonArray();
			for (String position : state.hiddenPositions()) {
				String[] parts = position.split(",", 3);
				if (parts.length != 3) {
					continue;
				}

				JsonObject hiddenPosition = new JsonObject();
				hiddenPosition.addProperty("x", Integer.parseInt(parts[0]));
				hiddenPosition.addProperty("y", Integer.parseInt(parts[1]));
				hiddenPosition.addProperty("z", Integer.parseInt(parts[2]));
				hidden.add(hiddenPosition);
			}

			object.add("hidden", hidden);
			datasets.add(object);
		}

		root.add("datasets", datasets);

		try {
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(root, writer);
			}
		} catch (IOException exception) {
			throw new OreDataException("Failed to write " + path + ": " + exception.getMessage(), exception);
		}
	}

	private boolean hasIdentity(OreDataset dataset) {
		return dataset != null
			&& !dataset.dimension().isBlank()
			&& !dataset.seed().isBlank()
			&& !dataset.version().isBlank();
	}

	private String datasetKey(OreDataset dataset) {
		return datasetKey(dataset.dimension(), dataset.seed(), dataset.version());
	}

	private String datasetKey(HiddenDatasetState state) {
		return datasetKey(state.dimension(), state.seed(), state.version());
	}

	private String datasetKey(String dimension, String seed, String version) {
		return dimension + "|" + seed + "|" + version;
	}

	private String positionKey(class_2338 pos) {
		return positionKey(pos.method_10263(), pos.method_10264(), pos.method_10260());
	}

	private String positionKey(int x, int y, int z) {
		return x + "," + y + "," + z;
	}

	private String readString(JsonObject object, String key) {
		JsonElement element = object.get(key);
		if (element == null || !element.isJsonPrimitive()) {
			return "";
		}

		return element.getAsString();
	}

	private Integer readInt(JsonObject object, String key) {
		JsonElement element = object.get(key);
		if (element == null || !element.isJsonPrimitive() || !element.getAsJsonPrimitive().isNumber()) {
			return null;
		}

		double value = element.getAsDouble();
		if (!Double.isFinite(value) || value != Math.rint(value)) {
			return null;
		}

		return (int) value;
	}

	private record HiddenDatasetState(
		String dimension,
		String source,
		String seed,
		String version,
		Set<String> hiddenPositions
	) {
		private HiddenDatasetState {
			hiddenPositions = Set.copyOf(hiddenPositions);
		}
	}
}
