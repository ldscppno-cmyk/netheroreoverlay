package io.armi.netheroreoverlay.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public final class OreMarkerStore {
	public static final int DEFAULT_MAX_RENDER_DISTANCE = 384;

	private final String dimension;
	private final int maxRenderDistance;
	private final double maxRenderDistanceSqr;
	private final Map<class_1923, List<OreMarker>> markersByChunk;
	private final int markerCount;

	private OreMarkerStore(String dimension, int maxRenderDistance, Map<class_1923, List<OreMarker>> markersByChunk, int markerCount) {
		this.dimension = dimension;
		this.maxRenderDistance = maxRenderDistance;
		this.maxRenderDistanceSqr = (double) maxRenderDistance * (double) maxRenderDistance;
		this.markersByChunk = markersByChunk;
		this.markerCount = markerCount;
	}

	public static OreMarkerStore empty() {
		return new OreMarkerStore("", DEFAULT_MAX_RENDER_DISTANCE, Map.of(), 0);
	}

	public static OreMarkerStore fromDataset(OreDataset dataset) {
		if (dataset.ores().isEmpty() || dataset.dimension().isBlank()) {
			return empty();
		}

		Map<class_1923, List<OreMarker>> mutableBuckets = new LinkedHashMap<>();
		for (OreMarker marker : dataset.ores()) {
			class_1923 chunkPos = new class_1923(marker.chunkX(), marker.chunkZ());
			mutableBuckets.computeIfAbsent(chunkPos, ignored -> new ArrayList<>()).add(marker);
		}

		Map<class_1923, List<OreMarker>> buckets = new LinkedHashMap<>();
		for (Map.Entry<class_1923, List<OreMarker>> entry : mutableBuckets.entrySet()) {
			buckets.put(entry.getKey(), List.copyOf(entry.getValue()));
		}

		return new OreMarkerStore(dataset.dimension(), DEFAULT_MAX_RENDER_DISTANCE, Map.copyOf(buckets), dataset.markerCount());
	}

	public int markerCount() {
		return markerCount;
	}

	public int maxRenderDistance() {
		return maxRenderDistance;
	}

	public boolean hasMarkerAt(String currentDimension, class_2338 pos) {
		if (markerCount == 0 || !sameDimension(dimension, currentDimension)) {
			return false;
		}

		List<OreMarker> bucket = markersByChunk.get(new class_1923(Math.floorDiv(pos.method_10263(), 16), Math.floorDiv(pos.method_10260(), 16)));
		if (bucket == null) {
			return false;
		}

		for (OreMarker marker : bucket) {
			if (marker.x() == pos.method_10263() && marker.y() == pos.method_10264() && marker.z() == pos.method_10260()) {
				return true;
			}
		}

		return false;
	}

	public List<OreMarker> getVisibleMarkers(String currentDimension, class_243 position) {
		if (markerCount == 0 || !sameDimension(dimension, currentDimension)) {
			return List.of();
		}

		int minBlockX = (int) Math.floor(position.field_1352) - maxRenderDistance;
		int maxBlockX = (int) Math.floor(position.field_1352) + maxRenderDistance;
		int minBlockZ = (int) Math.floor(position.field_1350) - maxRenderDistance;
		int maxBlockZ = (int) Math.floor(position.field_1350) + maxRenderDistance;
		int minChunkX = Math.floorDiv(minBlockX, 16);
		int maxChunkX = Math.floorDiv(maxBlockX, 16);
		int minChunkZ = Math.floorDiv(minBlockZ, 16);
		int maxChunkZ = Math.floorDiv(maxBlockZ, 16);

		List<OreMarker> visibleMarkers = new ArrayList<>();
		for (int chunkX = minChunkX; chunkX <= maxChunkX; chunkX++) {
			for (int chunkZ = minChunkZ; chunkZ <= maxChunkZ; chunkZ++) {
				List<OreMarker> bucket = markersByChunk.get(new class_1923(chunkX, chunkZ));
				if (bucket == null) {
					continue;
				}

				for (OreMarker marker : bucket) {
					// Use horizontal distance so ores stay visible when the player is far above or below them.
					if (marker.horizontalDistanceToSqr(position.field_1352, position.field_1350) <= maxRenderDistanceSqr) {
						visibleMarkers.add(marker);
					}
				}
			}
		}

		return visibleMarkers;
	}

	private boolean sameDimension(String expectedDimension, String currentDimension) {
		if (expectedDimension == null || currentDimension == null) {
			return false;
		}

		if (expectedDimension.equals(currentDimension)) {
			return true;
		}

		return "minecraft:the_nether".equals(expectedDimension) && currentDimension.endsWith("the_nether");
	}
}
