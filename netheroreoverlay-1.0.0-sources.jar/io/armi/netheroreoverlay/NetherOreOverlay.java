package io.armi.netheroreoverlay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class NetherOreOverlay {
	public static final String MOD_ID = "netheroreoverlay";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private NetherOreOverlay() {
	}
}
