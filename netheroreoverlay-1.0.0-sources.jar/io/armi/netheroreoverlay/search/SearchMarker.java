package io.armi.netheroreoverlay.search;

import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;

public record SearchMarker(
	String oreId,
	int x,
	int y,
	int z,
	OptionalDouble distance,
	OptionalInt clusterSize,
	Map<String, String> metadata
) {
	public SearchMarker {
		if (oreId == null || oreId.isBlank()) {
			throw new IllegalArgumentException("oreId cannot be blank");
		}

		distance = distance == null ? OptionalDouble.empty() : distance;
		clusterSize = clusterSize == null ? OptionalInt.empty() : clusterSize;
		metadata = metadata == null ? Map.of() : Map.copyOf(metadata);
	}
}
