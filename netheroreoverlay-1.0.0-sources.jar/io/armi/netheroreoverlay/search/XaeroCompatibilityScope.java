package io.armi.netheroreoverlay.search;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class XaeroCompatibilityScope implements AutoCloseable {
	private final List<ServerFieldState> states;

	private XaeroCompatibilityScope(List<ServerFieldState> states) {
		this.states = states;
	}

	static XaeroCompatibilityScope open() {
		try {
			Class<?> registryClass = Class.forName("xaero.lib.common.config.channel.register.ConfigChannelRegistry");
			Field instanceField = registryClass.getField("INSTANCE");
			Object registry = instanceField.get(null);
			Method iteratorMethod = registryClass.getMethod("iterator");
			@SuppressWarnings("unchecked")
			Iterator<Object> iterator = (Iterator<Object>) iteratorMethod.invoke(registry);

			List<ServerFieldState> states = new ArrayList<>();
			while (iterator.hasNext()) {
				Object channel = iterator.next();
				Method getServerConfigManager = channel.getClass().getMethod("getServerConfigManager");
				Object serverConfigManager = getServerConfigManager.invoke(channel);
				Field serverField = serverConfigManager.getClass().getDeclaredField("server");
				serverField.setAccessible(true);
				Object originalValue = serverField.get(serverConfigManager);
				states.add(new ServerFieldState(serverConfigManager, serverField, originalValue));
				serverField.set(serverConfigManager, null);
			}

			return new XaeroCompatibilityScope(states);
		} catch (ClassNotFoundException ignored) {
			return new XaeroCompatibilityScope(List.of());
		} catch (ReflectiveOperationException exception) {
			throw new RuntimeException("Failed to activate Xaero compatibility scope.", exception);
		}
	}

	@Override
	public void close() {
		for (ServerFieldState state : states) {
			try {
				state.serverField().set(state.serverConfigManager(), state.originalValue());
			} catch (IllegalAccessException exception) {
				throw new RuntimeException("Failed to restore Xaero server state.", exception);
			}
		}
	}

	private record ServerFieldState(Object serverConfigManager, Field serverField, Object originalValue) {
	}
}
