package io.armi.netheroreoverlay.search;

public interface OreSearchProvider {
	OreSearchProviderResult search(OreSearchRequest request) throws OreSearchException;
}
