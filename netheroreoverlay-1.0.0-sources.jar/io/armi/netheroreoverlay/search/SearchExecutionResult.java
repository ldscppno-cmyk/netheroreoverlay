package io.armi.netheroreoverlay.search;

import io.armi.netheroreoverlay.data.OreDataset;

public record SearchExecutionResult(
	OreDataset dataset,
	ProviderMode actualMode,
	String providerId,
	String accuracy,
	boolean fromCache
) {
	public int markerCount() {
		return dataset.markerCount();
	}
}
