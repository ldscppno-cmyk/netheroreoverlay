package io.armi.netheroreoverlay.search;

import java.util.List;
import java.util.Map;

public final class LocalSearchRules {
	private static final Map<String, Integer> SEARCH_RADIUS_BY_ORE = Map.of(
		"quartz", 2,
		"gold", 2,
		"ancient_debris", 3
	);

	private static final List<String> SEARCHABLE_ORES = List.copyOf(SEARCH_RADIUS_BY_ORE.keySet());

	private LocalSearchRules() {
	}

	public static List<String> searchableOreIds() {
		return SEARCHABLE_ORES;
	}

	public static boolean isSearchableOre(String oreId) {
		return SEARCH_RADIUS_BY_ORE.containsKey(oreId);
	}

	public static int getSearchRadiusChunks(String oreId) throws OreSearchException {
		Integer radius = SEARCH_RADIUS_BY_ORE.get(oreId);
		if (radius == null) {
			throw new OreSearchException("No local search radius is defined for " + oreId + ".");
		}

		return radius;
	}

	public static boolean matchesFilter(String oreId, int exactCount, ClusterFilter filter) throws OreSearchException {
		if (filter == ClusterFilter.ALL) {
			return true;
		}

		String size = classifySize(oreId, exactCount);
		if (filter == ClusterFilter.BIG) {
			return "big".equals(size);
		}

		return !"small".equals(size);
	}

	public static String classifySize(String oreId, int exactCount) throws OreSearchException {
		return switch (oreId) {
			case "quartz" -> exactCount <= 8 ? "small" : exactCount <= 18 ? "medium" : "big";
			case "gold" -> exactCount <= 4 ? "small" : exactCount <= 8 ? "medium" : "big";
			case "ancient_debris" -> exactCount <= 1 ? "small" : exactCount <= 2 ? "medium" : "big";
			default -> throw new OreSearchException("No cluster size table is defined for " + oreId + ".");
		};
	}
}
