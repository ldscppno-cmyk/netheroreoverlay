package io.armi.netheroreoverlay.search;

import java.util.List;

import io.armi.netheroreoverlay.data.OreType;

public record SearchState(
	String seed,
	OreType oreType,
	ClusterFilter clusterFilter
) {
	private static final List<OreType> SEARCHABLE_ORES = List.of(
		OreType.QUARTZ,
		OreType.GOLD,
		OreType.ANCIENT_DEBRIS
	);

	public SearchState {
		seed = seed == null ? "" : seed.trim();
		oreType = sanitizeOre(oreType);
		clusterFilter = clusterFilter == null ? ClusterFilter.MEDIUM : clusterFilter;
	}

	public static SearchState defaults() {
		return new SearchState("", OreType.QUARTZ, ClusterFilter.MEDIUM);
	}

	public static List<OreType> searchableOres() {
		return SEARCHABLE_ORES;
	}

	public static OreType sanitizeOre(OreType oreType) {
		if (oreType != null && SEARCHABLE_ORES.contains(oreType)) {
			return oreType;
		}

		return OreType.QUARTZ;
	}
}
