package io.armi.netheroreoverlay.search;

import java.io.IOException;
import java.net.Proxy;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BooleanSupplier;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.yggdrasil.ServicesKeySet;
import com.mojang.serialization.Lifecycle;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.class_11548;
import net.minecraft.class_11560;
import net.minecraft.class_11561;
import net.minecraft.class_11755;
import net.minecraft.class_11869;
import net.minecraft.class_12086;
import net.minecraft.class_12096;
import net.minecraft.class_12176;
import net.minecraft.class_12180;
import net.minecraft.class_1267;
import net.minecraft.class_155;
import net.minecraft.class_156;
import net.minecraft.class_1923;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2966;
import net.minecraft.class_31;
import net.minecraft.class_32;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3283;
import net.minecraft.class_3286;
import net.minecraft.class_3324;
import net.minecraft.class_3551;
import net.minecraft.class_5285;
import net.minecraft.class_5317;
import net.minecraft.class_5359;
import net.minecraft.class_5363;
import net.minecraft.class_6396;
import net.minecraft.class_6904;
import net.minecraft.class_7145;
import net.minecraft.class_7225;
import net.minecraft.class_7237;
import net.minecraft.class_7497;
import net.minecraft.class_7701;
import net.minecraft.class_7712;
import net.minecraft.class_7723;
import net.minecraft.class_7924;
import net.minecraft.class_8743;
import net.minecraft.class_9191;
import net.minecraft.server.MinecraftServer;
import net.fabricmc.fabric.api.resource.v1.DataResourceStore;

final class WorldgenClusterScanner {
	private static final AtomicBoolean BOOTSTRAPPED = new AtomicBoolean(false);
	private static final class_7497 NO_SERVICES = new class_7497(
		null,
		ServicesKeySet.EMPTY,
		null,
		new EmptyUserNameToIdResolver(),
		new EmptyProfileResolver()
	);

	public List<ScannedCluster> scan(OreSearchRequest request) throws OreSearchException {
		request.validateBaseConstraints();
		ensureBootstrapped();

		try {
			Files.createDirectories(request.runtimeDirectory());
		} catch (IOException exception) {
			throw new OreSearchException("Failed to prepare runtime directory: " + request.runtimeDirectory(), exception);
		}

		try {
			return runHeadlessScan(request);
		} catch (InterruptedException exception) {
			Thread.currentThread().interrupt();
			throw new OreSearchException("Exact worldgen search was interrupted.", exception);
		}
	}

	private void ensureBootstrapped() {
		if (BOOTSTRAPPED.compareAndSet(false, true)) {
			class_155.method_36208();
			class_2966.method_12851();
			class_2966.method_17598();
			class_156.method_29476();
		}
	}

	private List<ScannedCluster> runHeadlessScan(OreSearchRequest request) throws OreSearchException, InterruptedException {
		try (XaeroCompatibilityScope ignored = XaeroCompatibilityScope.open()) {
			class_32 levelStorageSource = class_32.method_26999(request.runtimeDirectory());
			try (class_32.class_5143 storageAccess = levelStorageSource.method_27002("netheroreoverlay-search")) {
				class_3283 packRepository = class_3286.method_45285(storageAccess);
				SearchServer server = MinecraftServer.method_29740(thread -> SearchServer.create(thread, storageAccess, packRepository, request));
				server.method_3777().join();
				if (server.failure() != null) {
					throw server.failure();
				}
				return server.result();
			}
		} catch (IOException exception) {
			throw new OreSearchException("Failed to open search runtime storage.", exception);
		}
	}

	record ScannedCluster(String oreId, int x, int y, int z, int exactCount, double distance) {
	}

	private static final class SearchServer extends MinecraftServer {
		private final class_9191 sampleLogger = new class_9191(4);
		private final Map<DataResourceStore.Key<?>, Object> dataResourceStore = new IdentityHashMap<>();
		private final OreSearchRequest request;
		private volatile List<ScannedCluster> result = List.of();
		private volatile RuntimeException failure;
		private boolean scanned;

		private SearchServer(
			Thread serverThread,
			class_32.class_5143 storageAccess,
			class_3283 packRepository,
			class_6904 worldStem,
			OreSearchRequest request
		) {
			super(
				serverThread,
				storageAccess,
				packRepository,
				worldStem,
				Proxy.NO_PROXY,
				class_3551.method_15450(),
				NO_SERVICES,
				class_11548.method_72290()
			);
			this.request = request;
		}

		static SearchServer create(
			Thread serverThread,
			class_32.class_5143 storageAccess,
			class_3283 packRepository,
			OreSearchRequest request
		) {
			packRepository.method_14445();
			class_7712 dataConfiguration = new class_7712(
				new class_5359(List.of("vanilla"), List.of()),
				class_7701.field_40183
			);
			var levelSettings = new net.minecraft.class_1940(
				"NetherOreOverlay Search",
				class_1934.field_9220,
				false,
				class_1267.field_5802,
				true,
				new net.minecraft.class_1928(class_7701.field_40183),
				dataConfiguration
			);
			class_7237.class_7238 packConfig = new class_7237.class_7238(packRepository, dataConfiguration, false, true);
			class_7237.class_6906 initConfig = new class_7237.class_6906(
				packConfig,
				class_2170.class_5364.field_25420,
				class_12086.field_63185
			);
			final long seed;
			try {
				seed = request.parsedSeed();
			} catch (OreSearchException exception) {
				throw new IllegalStateException(exception.getMessage(), exception);
			}

			try {
				class_6904 worldStem = class_156.method_43499(
					executor -> class_7237.method_42098(
						initConfig,
						context -> createDataLoadOutput(context, levelSettings, seed),
						class_6904::new,
						class_156.method_18349(),
						executor
					)
				).get();
				return new SearchServer(serverThread, storageAccess, packRepository, worldStem, request);
			} catch (ExecutionException exception) {
				throw new IllegalStateException("Failed to initialize the 1.21.11 Nether generation path.", exception.getCause());
			} catch (Exception exception) {
				throw new IllegalStateException("Failed to initialize the search world stem.", exception);
			}
		}

		private static class_7237.class_7661<class_31> createDataLoadOutput(
			class_7237.class_7660 context,
			net.minecraft.class_1940 levelSettings,
			long seed
		) {
			class_2378<class_5363> levelStemRegistry = new class_2370<>(class_7924.field_41224, Lifecycle.stable()).method_40276();
			class_7225.class_7226<class_7145> presets = context.comp_989().method_46762(class_7924.field_41250);
			class_7723.class_7725 dimensions = presets
				.method_46747(class_5317.field_25050)
				.comp_349()
				.method_45546()
				.method_45518(levelStemRegistry);
			class_5285 worldOptions = new class_5285(seed, true, false);
			class_31 levelData = new class_31(
				levelSettings,
				worldOptions,
				dimensions.comp_1018(),
				dimensions.method_45536()
			);
			return new class_7237.class_7661<>(levelData, dimensions.method_45537());
		}

		@Override
		public boolean method_3823() {
			this.method_3846(new class_3324(this, this.method_46221(), this.field_24371, new class_11869()) {
			});
			class_12180.method_75554(class_12176.field_64086);
			this.method_3735();
			for (class_3218 level : this.method_3738()) {
				level.field_13957 = true;
			}
			return true;
		}

		@Override
		public void method_3748(BooleanSupplier shouldKeepTicking) {
			super.method_3748(shouldKeepTicking);
			if (this.scanned) {
				return;
			}

			this.scanned = true;
			try {
				this.result = this.scanNether();
			} catch (RuntimeException exception) {
				this.failure = exception;
			} finally {
				this.method_3747(false);
			}
		}

		private List<ScannedCluster> scanNether() {
			class_3218 level = this.method_3847(class_1937.field_25180);
			if (level == null) {
				throw new IllegalStateException("Failed to resolve the Nether level in the generated search world.");
			}
			class_3215 chunkSource = level.method_14178();
			class_2339 cursor = new class_2339();
			Set<class_2248> targetBlocks = blocksForOre(request.oreId());
			LongSet orePositions = new LongOpenHashSet();
			final int chunkRadius;
			try {
				chunkRadius = request.searchChunkRadius();
			} catch (OreSearchException exception) {
				throw new IllegalStateException(exception.getMessage(), exception);
			}

			for (int chunkX = request.originChunkX() - chunkRadius; chunkX <= request.originChunkX() + chunkRadius; chunkX++) {
				for (int chunkZ = request.originChunkZ() - chunkRadius; chunkZ <= request.originChunkZ() + chunkRadius; chunkZ++) {
					class_2791 chunkAccess = chunkSource.method_12121(chunkX, chunkZ, class_2806.field_12803, true);
					if (!(chunkAccess instanceof class_2818 levelChunk)) {
						throw new IllegalStateException("Expected a fully generated chunk at " + chunkX + "," + chunkZ + ".");
					}

					class_1923 chunkPos = levelChunk.method_12004();
					for (int blockX = chunkPos.method_8326(); blockX <= chunkPos.method_8327(); blockX++) {
						for (int blockZ = chunkPos.method_8328(); blockZ <= chunkPos.method_8329(); blockZ++) {
							for (int blockY = level.method_31607(); blockY <= level.method_31600(); blockY++) {
								cursor.method_10103(blockX, blockY, blockZ);
								class_2680 blockState = level.method_8320(cursor);
								if (targetBlocks.contains(blockState.method_26204())) {
									orePositions.add(cursor.method_10063());
								}
							}
						}
					}
				}
			}

			return clusterPositions(request, orePositions);
		}

		private List<ScannedCluster> clusterPositions(OreSearchRequest request, LongSet orePositions) {
			LongOpenHashSet remaining = new LongOpenHashSet();
			remaining.addAll(orePositions);
			LongArrayList stack = new LongArrayList();
			List<ScannedCluster> clusters = new ArrayList<>();

			LongIterator iterator = orePositions.iterator();
			while (iterator.hasNext()) {
				long start = iterator.nextLong();
				if (!remaining.remove(start)) {
					continue;
				}

				List<Long> cluster = new ArrayList<>();
				stack.add(start);
				while (!stack.isEmpty()) {
					long current = stack.removeLong(stack.size() - 1);
					cluster.add(current);

					int x = class_2338.method_10061(current);
					int y = class_2338.method_10071(current);
					int z = class_2338.method_10083(current);
					for (int deltaX = -1; deltaX <= 1; deltaX++) {
						for (int deltaY = -1; deltaY <= 1; deltaY++) {
							for (int deltaZ = -1; deltaZ <= 1; deltaZ++) {
								if (deltaX == 0 && deltaY == 0 && deltaZ == 0) {
									continue;
								}

								long neighbor = class_2338.method_10064(x + deltaX, y + deltaY, z + deltaZ);
								if (remaining.remove(neighbor)) {
									stack.add(neighbor);
								}
							}
						}
					}
				}

				clusters.add(toCluster(request, cluster));
			}

			clusters.sort(
				Comparator.comparingDouble(WorldgenClusterScanner.ScannedCluster::distance)
					.thenComparing(Comparator.comparingInt(WorldgenClusterScanner.ScannedCluster::exactCount).reversed())
					.thenComparingInt(WorldgenClusterScanner.ScannedCluster::x)
					.thenComparingInt(WorldgenClusterScanner.ScannedCluster::y)
					.thenComparingInt(WorldgenClusterScanner.ScannedCluster::z)
			);
			return List.copyOf(clusters);
		}

		private ScannedCluster toCluster(OreSearchRequest request, List<Long> cluster) {
			double sumX = 0.0d;
			double sumY = 0.0d;
			double sumZ = 0.0d;
			for (long packed : cluster) {
				sumX += class_2338.method_10061(packed);
				sumY += class_2338.method_10071(packed);
				sumZ += class_2338.method_10083(packed);
			}

			double centerX = sumX / cluster.size();
			double centerY = sumY / cluster.size();
			double centerZ = sumZ / cluster.size();
			long best = cluster.get(0);
			double bestDistance = Double.MAX_VALUE;
			for (long packed : cluster) {
				double deltaX = class_2338.method_10061(packed) - centerX;
				double deltaY = class_2338.method_10071(packed) - centerY;
				double deltaZ = class_2338.method_10083(packed) - centerZ;
				double score = deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ;
				if (score < bestDistance) {
					best = packed;
					bestDistance = score;
				}
			}

			int x = class_2338.method_10061(best);
			int y = class_2338.method_10071(best);
			int z = class_2338.method_10083(best);
			double distance = Math.abs(request.originX() - x) + Math.abs(request.originY() - y) + Math.abs(request.originZ() - z);
			return new ScannedCluster(request.oreId(), x, y, z, cluster.size(), distance);
		}

		private static Set<class_2248> blocksForOre(String oreId) {
			return switch (oreId) {
				case "quartz" -> Set.of(class_2246.field_10213);
				case "gold" -> Set.of(class_2246.field_23077);
				case "ancient_debris" -> Set.of(class_2246.field_22109);
				default -> throw new IllegalStateException("Unsupported exact ore search: " + oreId);
			};
		}

		List<ScannedCluster> result() {
			return result;
		}

		RuntimeException failure() {
			return failure;
		}

		@Override
		public class_8743 method_56593() {
			return this.sampleLogger;
		}

		@Override
		public boolean method_56626() {
			return false;
		}

		@Override
		public void method_16208() {
			this.method_5383();
		}

		@Override
		public class_6396 method_3859(class_6396 report) {
			report.method_37122("Type", "NetherOreOverlay search helper");
			return report;
		}

		@Override
		public void method_3744(net.minecraft.class_128 report) {
			super.method_3744(report);
			this.failure = new IllegalStateException(report.method_60920(net.minecraft.class_9813.field_52181));
		}

		@Override
		public boolean method_3754() {
			return false;
		}

		@Override
		public class_12086 method_74994() {
			return class_12086.field_63185;
		}

		@Override
		public class_12096 method_74995() {
			return class_12086.field_63185;
		}

		@Override
		public boolean method_3732() {
			return false;
		}

		@Override
		public boolean method_3816() {
			return false;
		}

		@Override
		public int method_30612() {
			return 0;
		}

		@Override
		public boolean method_3759() {
			return false;
		}

		@Override
		public boolean method_3860() {
			return false;
		}

		@Override
		public boolean method_9201() {
			return false;
		}

		@Override
		public boolean method_19466(class_11560 profile) {
			return false;
		}

		@Override
		public int method_3802() {
			return 1;
		}

		@Override
		public <T> T getOrThrow(DataResourceStore.Key<T> key) {
			return castStoredValue(Objects.requireNonNull(this.dataResourceStore.get(key)));
		}

		@SuppressWarnings("unchecked")
		private static <T> T castStoredValue(Object value) {
			return (T) value;
		}
	}

	private static final class EmptyUserNameToIdResolver implements class_11561 {
		@Override
		public void method_14508(class_11560 profile) {
		}

		@Override
		public Optional<class_11560> method_14515(String username) {
			return Optional.empty();
		}

		@Override
		public Optional<class_11560> method_14512(UUID uuid) {
			return Optional.empty();
		}

		@Override
		public void method_72367(boolean resolve) {
		}

		@Override
		public void method_14518() {
		}
	}

	private static final class EmptyProfileResolver implements class_11755 {
		@Override
		public Optional<GameProfile> method_73289(String name) {
			return Optional.empty();
		}

		@Override
		public Optional<GameProfile> method_73290(UUID uuid) {
			return Optional.empty();
		}
	}
}
