package io.armi.oreoverlay.search;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import io.armi.oreoverlay.OreOverlay;
import io.armi.oreoverlay.data.OreType;
import net.fabricmc.loader.api.FabricLoader;

public final class SearchStateStore {
	private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create();

	private final Path path;

	public SearchStateStore() {
		this(FabricLoader.getInstance().getConfigDir().resolve("oreoverlay").resolve("search-state.json"));
	}

	public SearchStateStore(Path path) {
		this.path = path;
	}

	public Path getPath() {
		return path;
	}

	public SearchState load() {
		if (!Files.exists(path)) {
			return SearchState.defaults();
		}

		try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
			JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
			String seed = readString(root, "seed").orElse("");
			OreType oreType = readString(root, "ore")
				.flatMap(OreType::fromId)
				.map(SearchState::sanitizeOre)
				.orElse(SearchState.defaults().oreType());
			ClusterFilter clusterFilter = readString(root, "clusterFilter").map(ClusterFilter::fromId).orElse(ClusterFilter.MEDIUM);
			return new SearchState(seed, oreType, clusterFilter);
		} catch (Exception exception) {
			OreOverlay.LOGGER.warn("Failed to load search state from {}", path, exception);
			return SearchState.defaults();
		}
	}

	public void save(SearchState state) {
		JsonObject root = new JsonObject();
		root.addProperty("seed", state.seed());
		root.addProperty("ore", state.oreType().id());
		root.addProperty("clusterFilter", state.clusterFilter().id());

		try {
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
				GSON.toJson(root, writer);
			}
		} catch (IOException exception) {
			OreOverlay.LOGGER.warn("Failed to save search state to {}", path, exception);
		}
	}

	private Optional<String> readString(JsonObject root, String key) {
		if (!root.has(key) || !root.get(key).isJsonPrimitive()) {
			return Optional.empty();
		}

		return Optional.ofNullable(root.getAsJsonPrimitive(key).getAsString());
	}
}
