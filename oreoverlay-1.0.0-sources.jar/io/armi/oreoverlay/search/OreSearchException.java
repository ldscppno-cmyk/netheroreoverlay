package io.armi.oreoverlay.search;

public class OreSearchException extends Exception {
	public OreSearchException(String message) {
		super(message);
	}

	public OreSearchException(String message, Throwable cause) {
		super(message, cause);
	}
}
