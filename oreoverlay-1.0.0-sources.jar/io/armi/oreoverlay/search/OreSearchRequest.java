package io.armi.oreoverlay.search;

import java.nio.file.Path;
import java.util.OptionalLong;
import net.minecraft.class_5285;

public record OreSearchRequest(
	String seed,
	String dimension,
	String version,
	String oreId,
	ClusterFilter clusterFilter,
	int originX,
	int originY,
	int originZ,
	Path runtimeDirectory
) {
	public static final String SUPPORTED_DIMENSION = "minecraft:overworld";
	public static final String SUPPORTED_VERSION = "1.21.11";

	public OreSearchRequest {
		if (seed == null || seed.isBlank()) {
			throw new IllegalArgumentException("seed cannot be blank");
		}
		if (dimension == null || dimension.isBlank()) {
			throw new IllegalArgumentException("dimension cannot be blank");
		}
		if (version == null || version.isBlank()) {
			throw new IllegalArgumentException("version cannot be blank");
		}
		if (oreId == null || oreId.isBlank()) {
			throw new IllegalArgumentException("oreId cannot be blank");
		}
		if (clusterFilter == null) {
			throw new IllegalArgumentException("clusterFilter cannot be null");
		}
		if (runtimeDirectory == null) {
			throw new IllegalArgumentException("runtimeDirectory cannot be null");
		}
	}

	public long parsedSeed() throws OreSearchException {
		OptionalLong parsed = class_5285.method_46720(seed);
		if (parsed.isEmpty()) {
			throw new OreSearchException("Seed must not be blank.");
		}

		return parsed.getAsLong();
	}

	public String normalizedSeedString() throws OreSearchException {
		return Long.toString(parsedSeed());
	}

	public int originChunkX() {
		return Math.floorDiv(originX, 16);
	}

	public int originChunkZ() {
		return Math.floorDiv(originZ, 16);
	}

	public int searchChunkRadius() throws OreSearchException {
		return LocalSearchRules.getSearchRadiusChunks(oreId);
	}

	public void validateBaseConstraints() throws OreSearchException {
		if (!SUPPORTED_DIMENSION.equals(dimension)) {
			throw new OreSearchException("Only overworld searches are supported in v1.");
		}
		if (!SUPPORTED_VERSION.equals(version)) {
			throw new OreSearchException("Only Minecraft 1.21.11 is supported in v1.");
		}
		if (!LocalSearchRules.isSearchableOre(oreId)) {
			throw new OreSearchException("Unsupported search ore: " + oreId);
		}
	}
}
