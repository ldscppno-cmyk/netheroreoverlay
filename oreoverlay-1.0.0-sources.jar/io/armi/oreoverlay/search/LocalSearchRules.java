package io.armi.oreoverlay.search;

import java.util.List;
import java.util.Map;

public final class LocalSearchRules {
	private static final Map<String, Integer> SEARCH_RADIUS_BY_ORE = Map.of(
		"diamond", 3,
		"redstone", 3,
		"iron", 1,
		"gold", 2,
		"emerald", 5,
		"lapis", 2,
		"coal", 1,
		"copper", 1
	);

	private static final List<String> SEARCHABLE_ORES = List.copyOf(SEARCH_RADIUS_BY_ORE.keySet());

	private LocalSearchRules() {
	}

	public static List<String> searchableOreIds() {
		return SEARCHABLE_ORES;
	}

	public static boolean isSearchableOre(String oreId) {
		return SEARCH_RADIUS_BY_ORE.containsKey(oreId);
	}

	public static int getSearchRadiusChunks(String oreId) throws OreSearchException {
		Integer radius = SEARCH_RADIUS_BY_ORE.get(oreId);
		if (radius == null) {
			throw new OreSearchException("No local search radius is defined for " + oreId + ".");
		}

		return radius;
	}

	public static boolean matchesFilter(String oreId, int exactCount, ClusterFilter filter) throws OreSearchException {
		if (filter == ClusterFilter.ALL) {
			return true;
		}

		String size = classifySize(oreId, exactCount);
		if (filter == ClusterFilter.BIG) {
			return "big".equals(size);
		}

		return !"small".equals(size);
	}

	public static String classifySize(String oreId, int exactCount) throws OreSearchException {
		return switch (oreId) {
			case "diamond" -> exactCount <= 3 ? "small" : exactCount <= 7 ? "medium" : "big";
			case "redstone" -> exactCount <= 4 ? "small" : exactCount <= 7 ? "medium" : "big";
			case "iron" -> exactCount < 5 ? "small" : exactCount < 8 ? "medium" : "big";
			case "gold" -> exactCount < 6 ? "small" : exactCount < 9 ? "medium" : "big";
			case "emerald" -> exactCount < 2 ? "small" : "big";
			case "lapis" -> exactCount < 5 ? "small" : exactCount < 7 ? "medium" : "big";
			case "coal" -> exactCount < 18 ? "small" : exactCount < 25 ? "medium" : "big";
			case "copper" -> exactCount < 7 ? "small" : exactCount < 25 ? "medium" : "big";
			default -> throw new OreSearchException("No cluster size table is defined for " + oreId + ".");
		};
	}
}
