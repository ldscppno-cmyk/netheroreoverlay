package io.armi.oreoverlay.search;

import io.armi.oreoverlay.data.OreDataset;

public record SearchExecutionResult(
	OreDataset dataset,
	ProviderMode actualMode,
	String providerId,
	String accuracy,
	boolean fromCache
) {
	public int markerCount() {
		return dataset.markerCount();
	}
}
