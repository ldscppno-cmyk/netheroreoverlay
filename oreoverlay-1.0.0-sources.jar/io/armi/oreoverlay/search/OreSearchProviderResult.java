package io.armi.oreoverlay.search;

import java.util.List;

public record OreSearchProviderResult(
	ProviderMode actualMode,
	String providerId,
	String accuracy,
	List<SearchMarker> markers
) {
	public OreSearchProviderResult {
		if (actualMode == null || actualMode != ProviderMode.EXACT) {
			throw new IllegalArgumentException("actualMode must resolve to exact");
		}
		if (providerId == null || providerId.isBlank()) {
			throw new IllegalArgumentException("providerId cannot be blank");
		}
		if (accuracy == null || accuracy.isBlank()) {
			throw new IllegalArgumentException("accuracy cannot be blank");
		}

		markers = markers == null ? List.of() : List.copyOf(markers);
	}

	public int markerCount() {
		return markers.size();
	}
}
