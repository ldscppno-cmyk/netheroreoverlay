package io.armi.oreoverlay.search;

import java.util.concurrent.CompletionException;
import net.minecraft.class_11908;
import net.minecraft.class_12094;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import org.lwjgl.glfw.GLFW;

import io.armi.oreoverlay.OreOverlayClient;
import io.armi.oreoverlay.data.OreDataException;
import io.armi.oreoverlay.data.OreType;

public final class OreSearchScreen extends class_437 {
	private static final class_2561 SEED_PLACEHOLDER = class_2561.method_43470("World seed, e.g. -7037735424688343579");

	private final OreOverlayClient overlayClient;

	private SearchState state;
	private class_342 seedField;
	private class_4185 pasteSeedButton;
	private class_5676<OreType> oreButton;
	private class_5676<ClusterFilter> filterButton;
	private class_4185 fetchButton;
	private class_4185 resetHiddenButton;
	private class_4185 clearCacheButton;
	private class_4185 reloadButton;
	private class_4185 clearButton;
	private String statusMessage = "Fetch scans fresh 1.21.11 overworld chunks around your current position.";
	private boolean busy;

	public OreSearchScreen(OreOverlayClient overlayClient, SearchState initialState) {
		super(class_2561.method_43470("OreOverlay Search"));
		this.overlayClient = overlayClient;
		this.state = initialState == null ? SearchState.defaults() : initialState;
	}

	@Override
	protected void method_25426() {
		int panelWidth = 320;
		int left = (this.field_22789 - panelWidth) / 2;
		int top = Math.max(32, this.field_22790 / 5);
		int seedFieldWidth = 214;

		this.seedField = this.method_37063(new class_342(this.field_22793, left, top + 22, seedFieldWidth, 20, class_2561.method_43470("Seed")));
		this.seedField.method_1880(64);
		this.seedField.method_1852(this.state.seed());
		this.seedField.method_1863(value -> {
			this.state = new SearchState(value, selectedOre(), selectedFilter());
			persistState();
			refreshButtons();
		});
		this.pasteSeedButton = this.method_37063(
			class_4185.method_46430(class_2561.method_43470("Paste Seed"), button -> pasteSeed()).method_46434(left + seedFieldWidth + 6, top + 22, panelWidth - seedFieldWidth - 6, 20).method_46431()
		);

		this.oreButton = this.method_37063(
			class_5676.method_32606(this::oreLabel, this.state.oreType())
				.method_32620(SearchState.searchableOres())
				.method_32617(left, top + 58, 320, 20, class_2561.method_43470("Ore"), (button, oreType) -> {
					this.state = new SearchState(this.seedField.method_1882(), oreType, selectedFilter());
					persistState();
					refreshButtons();
				})
		);
		this.filterButton = this.method_37063(
			class_5676.method_32606(this::filterLabel, this.state.clusterFilter())
				.method_32624(ClusterFilter.ALL, ClusterFilter.MEDIUM, ClusterFilter.BIG)
				.method_32617(left, top + 92, panelWidth, 20, class_2561.method_43470("Cluster filter"), (button, clusterFilter) -> {
					this.state = new SearchState(this.seedField.method_1882(), selectedOre(), clusterFilter);
					persistState();
					refreshButtons();
				})
		);

		this.fetchButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Fetch"), button -> beginFetch()).method_46434(left, top + 132, 102, 20).method_46431());
		this.reloadButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Reload"), button -> reloadOverlayData()).method_46434(left + 109, top + 132, 102, 20).method_46431());
		this.clearButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Clear Results"), button -> clearResults()).method_46434(left + 218, top + 132, 102, 20).method_46431());
		this.resetHiddenButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Reset Hidden"), button -> resetHiddenMarkers()).method_46434(left, top + 158, 157, 20).method_46431());
		this.clearCacheButton = this.method_37063(class_4185.method_46430(class_2561.method_43470("Clear Cache"), button -> clearQueryCache()).method_46434(left + 163, top + 158, 157, 20).method_46431());

		this.method_48265(this.seedField);
		refreshButtons();
	}

	@Override
	public boolean method_25404(class_11908 keyEvent) {
		if (keyEvent.comp_4795() == GLFW.GLFW_KEY_ENTER || keyEvent.comp_4795() == GLFW.GLFW_KEY_KP_ENTER) {
			if (this.fetchButton != null && this.fetchButton.field_22763) {
				beginFetch();
				return true;
			}
		}

		return super.method_25404(keyEvent);
	}

	@Override
	public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
		super.method_25394(guiGraphics, mouseX, mouseY, partialTick);

		int panelWidth = 320;
		int left = (this.field_22789 - panelWidth) / 2;
		int top = Math.max(32, this.field_22790 / 5);
		guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, top - 18, 0xFFFFFF);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Seed"), left, top + 10, 0xFFFFFF);
		renderSeedPlaceholder(guiGraphics);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Origin: " + originText()), left, top + 190, 0xC0C0C0);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Dimension: " + dimensionText()), left, top + 202, 0xC0C0C0);
		guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Overworld-only in v1. Ancient debris stays JSON-import-only."), left, top + 216, 0xD8A060);
		if (!currentDimension().equals(OreSearchRequest.SUPPORTED_DIMENSION)) {
			guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Fetch is disabled outside the overworld."), left, top + 228, 0xFF8080);
		}
		if (this.busy) {
			guiGraphics.method_27535(this.field_22793, class_2561.method_43470("Search running on a background thread..."), left, top + 240, 0xFFF080);
		}
		guiGraphics.method_27535(this.field_22793, class_2561.method_43470(this.statusMessage), left, top + 254, 0xA8D8FF);
	}

	private void renderSeedPlaceholder(class_332 guiGraphics) {
		if (this.seedField == null || !this.seedField.method_1882().isBlank()) {
			return;
		}

		guiGraphics.method_27535(this.field_22793, SEED_PLACEHOLDER, this.seedField.method_46426() + 4, this.seedField.method_46427() + 6, 0x80909090);
	}

	private void pasteSeed() {
		Long seed = currentWorldSeedIfPermitted();
		if (seed == null) {
			this.statusMessage = "Paste Seed is only available when you are OP in a local world.";
			refreshButtons();
			return;
		}

		this.seedField.method_1852(Long.toString(seed));
		this.statusMessage = "Pasted the current world seed into the search box.";
		this.method_25395(this.seedField);
		refreshButtons();
	}

	private void beginFetch() {
		if (this.busy) {
			return;
		}

		if (!currentDimension().equals(OreSearchRequest.SUPPORTED_DIMENSION)) {
			this.statusMessage = "Fetch is disabled outside the overworld in v1.";
			overlayClient.postClientMessage("OreOverlay: fetch is disabled outside the overworld in v1.");
			refreshButtons();
			return;
		}

		this.busy = true;
		this.statusMessage = "Searching around " + originText() + "...";
		persistState();
		refreshButtons();

		SearchState currentState = new SearchState(this.seedField.method_1882(), selectedOre(), selectedFilter());
		class_2338 origin = currentOrigin();
		this.overlayClient.searchMarkers(currentState, origin).whenComplete((result, error) -> this.field_22787.execute(() -> {
			this.busy = false;
			if (error != null) {
				Throwable cause = unwrap(error);
				String message = cause.getMessage() == null ? cause.getClass().getSimpleName() : cause.getMessage();
				this.statusMessage = "Search failed: " + message;
				this.overlayClient.postClientMessage("OreOverlay: search failed: " + message);
			} else {
				this.overlayClient.applySearchResult(result, true);
				this.statusMessage = "Loaded " + result.markerCount() + " markers via local exact search" + (result.fromCache() ? " cache." : ".");
			}
			refreshButtons();
		}));
	}

	private void reloadOverlayData() {
		this.overlayClient.reloadOreData(true);
		this.statusMessage = "Reloaded the current ores.json snapshot.";
		refreshButtons();
	}

	private void clearResults() {
		try {
			this.overlayClient.clearSearchResults(currentState());
			this.statusMessage = "Cleared the current overlay results.";
		} catch (OreDataException exception) {
			this.statusMessage = "Failed to clear results: " + exception.getMessage();
			this.overlayClient.postClientMessage("OreOverlay: clear failed: " + exception.getMessage());
		}
		refreshButtons();
	}

	private void resetHiddenMarkers() {
		try {
			int restoredMarkers = this.overlayClient.resetHiddenMarkers();
			this.statusMessage = restoredMarkers == 0
				? "No hidden markers were stored for the current dataset."
				: "Restored " + restoredMarkers + " hidden markers for the current dataset.";
		} catch (OreDataException exception) {
			this.statusMessage = "Failed to reset hidden markers: " + exception.getMessage();
			this.overlayClient.postClientMessage("OreOverlay: failed to reset hidden markers: " + exception.getMessage());
		}
		refreshButtons();
	}

	private void clearQueryCache() {
		try {
			int clearedEntries = this.overlayClient.clearQueryCache();
			this.statusMessage = clearedEntries == 0
				? "Query cache was already empty."
				: "Cleared " + clearedEntries + " cached query " + (clearedEntries == 1 ? "entry." : "entries.");
		} catch (OreSearchException exception) {
			this.statusMessage = "Failed to clear query cache: " + exception.getMessage();
			this.overlayClient.postClientMessage("OreOverlay: failed to clear query cache: " + exception.getMessage());
		}
		refreshButtons();
	}

	private SearchState currentState() {
		return new SearchState(this.seedField == null ? this.state.seed() : this.seedField.method_1882(), selectedOre(), selectedFilter());
	}

	private void persistState() {
		this.overlayClient.saveSearchState(currentState());
	}

	private void refreshButtons() {
		if (this.fetchButton == null) {
			return;
		}

		boolean hasWorld = this.field_22787 != null && this.field_22787.field_1724 != null && this.field_22787.field_1687 != null;
		boolean correctDimension = OreSearchRequest.SUPPORTED_DIMENSION.equals(currentDimension());
		boolean hasSeed = this.seedField != null && !this.seedField.method_1882().isBlank();
		boolean canPasteSeed = currentWorldSeedIfPermitted() != null;
		boolean hasHiddenMarkers = this.overlayClient.hiddenMarkerCount() > 0;
		this.fetchButton.field_22763 = !this.busy && hasWorld && correctDimension && hasSeed;
		this.pasteSeedButton.field_22763 = !this.busy && canPasteSeed;
		this.resetHiddenButton.field_22763 = !this.busy && hasHiddenMarkers;
		this.clearCacheButton.field_22763 = !this.busy;
		this.reloadButton.field_22763 = !this.busy;
		this.clearButton.field_22763 = !this.busy;
	}

	private Long currentWorldSeedIfPermitted() {
		if (this.field_22787 == null || this.field_22787.field_1724 == null || this.field_22787.method_1576() == null) {
			return null;
		}

		if (!this.field_22787.method_1576().method_3835(this.field_22787.field_1724.method_72498()).method_75009().method_75028(class_12094.field_63198)) {
			return null;
		}

		return this.field_22787.method_1576().method_30002().method_8412();
	}

	private class_2338 currentOrigin() {
		if (this.field_22787 == null || this.field_22787.field_1724 == null) {
			return class_2338.field_10980;
		}

		return class_2338.method_49638(this.field_22787.field_1724.method_73189());
	}

	private String originText() {
		if (this.field_22787 == null || this.field_22787.field_1724 == null) {
			return "No active player";
		}

		class_2338 origin = currentOrigin();
		return origin.method_10263() + " / " + origin.method_10264() + " / " + origin.method_10260();
	}

	private String dimensionText() {
		String dimension = currentDimension();
		return dimension.isBlank() ? "No active world" : dimension;
	}

	private String currentDimension() {
		if (this.field_22787 == null || this.field_22787.field_1687 == null) {
			return "";
		}

		return this.field_22787.field_1687.method_27983().method_29177().toString();
	}

	private OreType selectedOre() {
		return this.oreButton == null ? SearchState.sanitizeOre(this.state.oreType()) : this.oreButton.method_32603();
	}

	private ClusterFilter selectedFilter() {
		return this.filterButton == null ? this.state.clusterFilter() : this.filterButton.method_32603();
	}

	private class_2561 oreLabel(OreType oreType) {
		return class_2561.method_43470(switch (oreType) {
			case DIAMOND -> "Diamond";
			case REDSTONE -> "Redstone";
			case GOLD -> "Gold";
			case IRON -> "Iron";
			case EMERALD -> "Emerald";
			case LAPIS -> "Lapis Lazuli";
			case COAL -> "Coal";
			case COPPER -> "Copper";
			default -> oreType.id();
		});
	}

	private class_2561 filterLabel(ClusterFilter filter) {
		return class_2561.method_43470(switch (filter) {
			case ALL -> "All clusters";
			case MEDIUM -> "Medium+";
			case BIG -> "Big only";
		});
	}

	private Throwable unwrap(Throwable throwable) {
		if (throwable instanceof CompletionException completionException && completionException.getCause() != null) {
			return completionException.getCause();
		}

		return throwable;
	}
}
