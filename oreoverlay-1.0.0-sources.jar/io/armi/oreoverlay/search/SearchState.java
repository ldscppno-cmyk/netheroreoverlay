package io.armi.oreoverlay.search;

import java.util.List;

import io.armi.oreoverlay.data.OreType;

public record SearchState(
	String seed,
	OreType oreType,
	ClusterFilter clusterFilter
) {
	private static final List<OreType> SEARCHABLE_ORES = List.of(
		OreType.DIAMOND,
		OreType.REDSTONE,
		OreType.GOLD,
		OreType.IRON,
		OreType.EMERALD,
		OreType.LAPIS,
		OreType.COAL,
		OreType.COPPER
	);

	public SearchState {
		seed = seed == null ? "" : seed.trim();
		oreType = sanitizeOre(oreType);
		clusterFilter = clusterFilter == null ? ClusterFilter.MEDIUM : clusterFilter;
	}

	public static SearchState defaults() {
		return new SearchState("", OreType.DIAMOND, ClusterFilter.MEDIUM);
	}

	public static List<OreType> searchableOres() {
		return SEARCHABLE_ORES;
	}

	public static OreType sanitizeOre(OreType oreType) {
		if (oreType != null && SEARCHABLE_ORES.contains(oreType)) {
			return oreType;
		}

		return OreType.DIAMOND;
	}
}
