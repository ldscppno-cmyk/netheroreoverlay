package io.armi.oreoverlay.search;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

import io.armi.oreoverlay.OreOverlay;
import io.armi.oreoverlay.data.OreDataException;
import io.armi.oreoverlay.data.OreDataLoader;
import io.armi.oreoverlay.data.OreDataset;
import io.armi.oreoverlay.data.OreMarker;
import io.armi.oreoverlay.data.OreType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;
import net.minecraft.class_5285;

public final class OreSearchService {
	private final OreDataLoader overlayLoader = new OreDataLoader();
	private final SearchStateStore stateStore = new SearchStateStore();
	private final Path queryCacheDir = FabricLoader.getInstance().getConfigDir().resolve("oreoverlay").resolve("query-cache");
	private final ExecutorService executor = Executors.newSingleThreadExecutor(runnable -> {
		Thread thread = new Thread(runnable, "OreOverlay Search");
		thread.setDaemon(true);
		return thread;
	});
	private final ExactWorldgenProvider exactProvider = new ExactWorldgenProvider(new WorldgenClusterScanner());

	public SearchState loadState() {
		return stateStore.load();
	}

	public void saveState(SearchState state) {
		stateStore.save(state);
	}

	public CompletableFuture<SearchExecutionResult> search(SearchState state, class_2338 origin) {
		saveState(state);
		return CompletableFuture.supplyAsync(() -> {
			try {
				return searchBlocking(state, origin);
			} catch (OreSearchException | OreDataException exception) {
				throw new CompletionException(exception);
			}
		}, executor);
	}

	public SearchExecutionResult clearResults(SearchState state) throws OreDataException {
		saveState(state);
		OreDataset dataset = new OreDataset(
			OreSearchRequest.SUPPORTED_DIMENSION,
			"oreoverlay-cleared",
			normalizeSeedOrOriginal(state.seed()),
			OreSearchRequest.SUPPORTED_VERSION,
			List.of()
		);
		overlayLoader.write(dataset);
		return new SearchExecutionResult(dataset, ProviderMode.EXACT, "oreoverlay-cleared", "exact", false);
	}

	public int clearQueryCache() throws OreSearchException {
		if (!Files.exists(queryCacheDir)) {
			return 0;
		}

		final int entryCount;
		try (Stream<Path> children = Files.list(queryCacheDir)) {
			entryCount = (int) children.count();
		} catch (IOException exception) {
			throw new OreSearchException("Failed to clear query cache at " + queryCacheDir + ": " + exception.getMessage(), exception);
		}

		try {
			deleteRecursively(queryCacheDir);
			Files.createDirectories(queryCacheDir);
			return entryCount;
		} catch (IOException exception) {
			throw new OreSearchException("Failed to recreate query cache at " + queryCacheDir + ": " + exception.getMessage(), exception);
		}
	}

	private SearchExecutionResult searchBlocking(SearchState state, class_2338 origin) throws OreSearchException, OreDataException {
		String normalizedSeed = normalizeSeed(state.seed());
		Path requestDir = requestDirectory(normalizedSeed, state, origin);
		Path cacheFile = requestDir.resolve("result.json");
		if (Files.exists(cacheFile)) {
			pruneRuntimeDirectoryQuietly(requestDir.resolve("runtime"));
			try {
				OreDataset cachedDataset = new OreDataLoader(cacheFile).load();
				overlayLoader.write(cachedDataset);
				return new SearchExecutionResult(
					cachedDataset,
					resolveMode(cachedDataset.source()),
					cachedDataset.source(),
					resolveAccuracy(cachedDataset),
					true
				);
			} catch (OreDataException exception) {
				OreOverlay.LOGGER.warn("Ignoring invalid cached query result at {}", cacheFile, exception);
			}
		}

		OreSearchRequest request = new OreSearchRequest(
			state.seed(),
			OreSearchRequest.SUPPORTED_DIMENSION,
			OreSearchRequest.SUPPORTED_VERSION,
			state.oreType().id(),
			state.clusterFilter(),
			origin.method_10263(),
			origin.method_10264(),
			origin.method_10260(),
			requestDir.resolve("runtime")
		);

		OreSearchProviderResult providerResult;
		try {
			providerResult = exactProvider.search(request);
		} finally {
			pruneRuntimeDirectoryQuietly(request.runtimeDirectory());
		}

		OreDataset dataset = toDataset(request, providerResult, normalizedSeed);
		try {
			Files.createDirectories(requestDir);
		} catch (IOException exception) {
			throw new OreSearchException("Failed to create query cache directory: " + requestDir, exception);
		}
		new OreDataLoader(cacheFile).write(dataset);
		overlayLoader.write(dataset);
		return new SearchExecutionResult(dataset, providerResult.actualMode(), providerResult.providerId(), providerResult.accuracy(), false);
	}

	private OreDataset toDataset(OreSearchRequest request, OreSearchProviderResult providerResult, String normalizedSeed) {
		List<OreMarker> markers = new ArrayList<>();
		for (SearchMarker marker : providerResult.markers()) {
			OreType oreType = OreType.fromId(marker.oreId())
				.orElseThrow(() -> new IllegalStateException("Unsupported ore type returned by provider: " + marker.oreId()));
			Map<String, String> metadata = new LinkedHashMap<>(marker.metadata());
			metadata.put("provider", providerResult.providerId());
			metadata.put("accuracy", providerResult.accuracy());
			metadata.put("originX", Integer.toString(request.originX()));
			metadata.put("originY", Integer.toString(request.originY()));
			metadata.put("originZ", Integer.toString(request.originZ()));
			markers.add(
				new OreMarker(
					oreType,
					marker.x(),
					marker.y(),
					marker.z(),
					marker.distance().isPresent() ? OptionalDouble.of(marker.distance().getAsDouble()) : OptionalDouble.empty(),
					marker.clusterSize().isPresent() ? OptionalInt.of(marker.clusterSize().getAsInt()) : OptionalInt.empty(),
					metadata
				)
			);
		}

		return new OreDataset(
			request.dimension(),
			providerResult.providerId(),
			normalizedSeed,
			request.version(),
			markers
		);
	}

	private Path requestDirectory(String normalizedSeed, SearchState state, class_2338 origin) throws OreSearchException {
		String key = normalizedSeed
			+ "|"
			+ state.oreType().id()
			+ "|"
			+ state.clusterFilter().id()
			+ "|"
			+ Math.floorDiv(origin.method_10263(), 16)
			+ "|"
			+ Math.floorDiv(origin.method_10260(), 16)
			+ "|"
			+ Math.floorDiv(origin.method_10264(), 16);
		return queryCacheDir.resolve(sha256(key));
	}

	private String normalizeSeed(String seed) throws OreSearchException {
		var parsed = class_5285.method_46720(seed);
		if (parsed.isEmpty()) {
			throw new OreSearchException("Seed must not be blank.");
		}

		return Long.toString(parsed.getAsLong());
	}

	private String normalizeSeedOrOriginal(String seed) {
		try {
			return normalizeSeed(seed);
		} catch (OreSearchException ignored) {
			return seed == null ? "" : seed;
		}
	}

	private String sha256(String value) throws OreSearchException {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-256");
			byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
			StringBuilder builder = new StringBuilder(bytes.length * 2);
			for (byte current : bytes) {
				builder.append(String.format("%02x", current & 0xFF));
			}
			return builder.toString();
		} catch (NoSuchAlgorithmException exception) {
			throw new OreSearchException("SHA-256 is not available in this Java runtime.", exception);
		}
	}

	private ProviderMode resolveMode(String providerId) {
		return ProviderMode.EXACT;
	}

	private String resolveAccuracy(OreDataset dataset) {
		if (!dataset.ores().isEmpty()) {
			String accuracy = dataset.ores().getFirst().metadata().get("accuracy");
			if (accuracy != null && !accuracy.isBlank()) {
				return accuracy;
			}
		}

		return "exact";
	}

	private void pruneRuntimeDirectoryQuietly(Path runtimeDirectory) {
		if (!Files.exists(runtimeDirectory)) {
			return;
		}

		try {
			deleteRecursively(runtimeDirectory);
		} catch (OreSearchException exception) {
			OreOverlay.LOGGER.warn("Failed to remove temporary search runtime directory {}", runtimeDirectory, exception);
		}
	}

	private void deleteRecursively(Path root) throws OreSearchException {
		try (Stream<Path> walk = Files.walk(root)) {
			List<Path> paths = walk.sorted(Comparator.reverseOrder()).toList();
			for (Path path : paths) {
				Files.deleteIfExists(path);
			}
		} catch (IOException exception) {
			throw new OreSearchException("Failed to delete " + root + ": " + exception.getMessage(), exception);
		}
	}
}
