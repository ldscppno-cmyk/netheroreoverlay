package io.armi.oreoverlay.search;

public enum ClusterFilter {
	ALL("all"),
	MEDIUM("medium"),
	BIG("big");

	private final String id;

	ClusterFilter(String id) {
		this.id = id;
	}

	public String id() {
		return id;
	}

	public static ClusterFilter fromId(String id) {
		for (ClusterFilter filter : values()) {
			if (filter.id.equalsIgnoreCase(id)) {
				return filter;
			}
		}

		return MEDIUM;
	}
}
