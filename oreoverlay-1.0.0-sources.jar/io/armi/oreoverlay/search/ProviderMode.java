package io.armi.oreoverlay.search;

public enum ProviderMode {
	EXACT("exact");

	private final String id;

	ProviderMode(String id) {
		this.id = id;
	}

	public String id() {
		return id;
	}

	public static ProviderMode fromId(String id) {
		return EXACT;
	}
}
