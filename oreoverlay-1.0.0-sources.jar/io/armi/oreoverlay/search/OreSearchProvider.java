package io.armi.oreoverlay.search;

public interface OreSearchProvider {
	OreSearchProviderResult search(OreSearchRequest request) throws OreSearchException;
}
