package io.armi.oreoverlay.search;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.OptionalInt;

public final class ExactWorldgenProvider implements OreSearchProvider {
	private static final String PROVIDER_ID = "oreoverlay-exact-worldgen";

	private final WorldgenClusterScanner scanner;

	public ExactWorldgenProvider(WorldgenClusterScanner scanner) {
		this.scanner = scanner;
	}

	@Override
	public OreSearchProviderResult search(OreSearchRequest request) throws OreSearchException {
		request.validateBaseConstraints();
		List<WorldgenClusterScanner.ScannedCluster> scannedClusters = scanner.scan(request);
		List<SearchMarker> markers = new ArrayList<>();
		for (WorldgenClusterScanner.ScannedCluster cluster : scannedClusters) {
			if (!LocalSearchRules.matchesFilter(request.oreId(), cluster.exactCount(), request.clusterFilter())) {
				continue;
			}

			Map<String, String> metadata = new LinkedHashMap<>();
			metadata.put("clusterCategory", LocalSearchRules.classifySize(request.oreId(), cluster.exactCount()));
			metadata.put("providerLabel", "Exact worldgen");
			markers.add(
				new SearchMarker(
					cluster.oreId(),
					cluster.x(),
					cluster.y(),
					cluster.z(),
					OptionalDouble.of(cluster.distance()),
					OptionalInt.of(cluster.exactCount()),
					metadata
				)
			);
		}

		return new OreSearchProviderResult(ProviderMode.EXACT, PROVIDER_ID, "exact", markers);
	}
}
