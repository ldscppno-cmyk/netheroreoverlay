package io.armi.oreoverlay.data;

import java.util.List;

public record OreDataset(
	String dimension,
	String source,
	String seed,
	String version,
	List<OreMarker> ores
) {
	public OreDataset {
		dimension = dimension == null ? "" : dimension;
		source = source == null ? "" : source;
		seed = seed == null ? "" : seed;
		version = version == null ? "" : version;
		ores = ores == null ? List.of() : List.copyOf(ores);
	}

	public static OreDataset empty() {
		return new OreDataset("", "", "", "", List.of());
	}

	public int markerCount() {
		return ores.size();
	}
}
