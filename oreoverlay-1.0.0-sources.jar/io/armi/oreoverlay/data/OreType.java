package io.armi.oreoverlay.data;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public enum OreType {
	DIAMOND("diamond", 0.35f, 0.95f, 1.00f, 0.45f),
	REDSTONE("redstone", 0.95f, 0.15f, 0.15f, 0.45f),
	GOLD("gold", 1.00f, 0.80f, 0.20f, 0.45f),
	IRON("iron", 0.82f, 0.82f, 0.86f, 0.45f),
	EMERALD("emerald", 0.20f, 0.85f, 0.30f, 0.45f),
	LAPIS("lapis", 0.20f, 0.40f, 0.95f, 0.45f),
	COAL("coal", 0.22f, 0.22f, 0.22f, 0.45f),
	COPPER("copper", 0.92f, 0.52f, 0.24f, 0.45f),
	ANCIENT_DEBRIS("ancient_debris", 0.48f, 0.26f, 0.10f, 0.45f);

	private static final Map<String, OreType> BY_ID = Arrays.stream(values())
		.collect(Collectors.toUnmodifiableMap(OreType::id, Function.identity()));

	private final String id;
	private final float red;
	private final float green;
	private final float blue;
	private final float alpha;

	OreType(String id, float red, float green, float blue, float alpha) {
		this.id = id;
		this.red = red;
		this.green = green;
		this.blue = blue;
		this.alpha = alpha;
	}

	public String id() {
		return id;
	}

	public float red() {
		return red;
	}

	public float green() {
		return green;
	}

	public float blue() {
		return blue;
	}

	public float alpha() {
		return alpha;
	}

	public static Optional<OreType> fromId(String id) {
		if (id == null) {
			return Optional.empty();
		}

		return Optional.ofNullable(BY_ID.get(id.toLowerCase(Locale.ROOT)));
	}
}
