package io.armi.oreoverlay;

import java.util.ArrayDeque;
import java.util.concurrent.CompletableFuture;
import java.util.Deque;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;

import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryUtil;

import io.armi.oreoverlay.data.OreDataException;
import io.armi.oreoverlay.data.OreDataLoader;
import io.armi.oreoverlay.data.OreDataset;
import io.armi.oreoverlay.data.HiddenMarkerStateStore;
import io.armi.oreoverlay.data.OreMarker;
import io.armi.oreoverlay.data.OreMarkerStore;
import io.armi.oreoverlay.search.OreSearchScreen;
import io.armi.oreoverlay.search.OreSearchException;
import io.armi.oreoverlay.search.OreSearchService;
import io.armi.oreoverlay.search.SearchExecutionResult;
import io.armi.oreoverlay.search.SearchState;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.event.client.player.ClientPlayerBlockBreakEvents;
import net.minecraft.class_10799;
import net.minecraft.class_11285;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

public class OreOverlayClient implements ClientModInitializer {
	private static final RenderPipeline FILLED_THROUGH_WALLS = class_10799.method_67887(
		RenderPipeline.builder(class_10799.field_56860)
			.withLocation(class_2960.method_60655(OreOverlay.MOD_ID, "pipeline/debug_filled_box_through_walls"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.build()
	);

	private static final class_9799 ALLOCATOR = new class_9799(class_1921.field_64009);
	private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
	private static final Vector3f MODEL_OFFSET = new Vector3f();
	private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();
	private static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.field_62558;

	private final OreDataLoader dataLoader = new OreDataLoader();
	private final HiddenMarkerStateStore hiddenMarkerStateStore = new HiddenMarkerStateStore();
	private final OreSearchService searchService = new OreSearchService();
	private final Deque<String> pendingMessages = new ArrayDeque<>();

	private class_287 buffer;
	private class_11285 vertexBuffer;
	private OreDataset currentDataset = OreDataset.empty();
	private OreMarkerStore markerStore = OreMarkerStore.empty();
	private class_304 toggleOverlayKey;
	private class_304 reloadDataKey;
	private class_304 openSearchKey;
	private boolean overlayEnabled = true;

	@Override
	public void onInitializeClient() {
		registerKeyBindings();
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::extractAndDrawBox);
		ClientTickEvents.END_CLIENT_TICK.register(this::handleClientTick);
		ClientPlayerBlockBreakEvents.AFTER.register(this::handleClientBlockBreak);
		reloadOreData(false);
		OreOverlay.LOGGER.info("OreOverlay client initialized");
	}

	private void registerKeyBindings() {
		toggleOverlayKey = KeyBindingHelper.registerKeyBinding(
			new class_304("key.oreoverlay.toggle_overlay", class_3675.class_307.field_1668, GLFW.GLFW_KEY_O, KEY_CATEGORY)
		);
		reloadDataKey = KeyBindingHelper.registerKeyBinding(
			new class_304("key.oreoverlay.reload_data", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, KEY_CATEGORY)
		);
		openSearchKey = KeyBindingHelper.registerKeyBinding(
			new class_304("key.oreoverlay.open_search", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, KEY_CATEGORY)
		);
	}

	private void handleClientTick(class_310 client) {
		flushPendingMessages(client);

		while (toggleOverlayKey.method_1436()) {
			overlayEnabled = !overlayEnabled;
			showClientMessage("OreOverlay: overlay " + (overlayEnabled ? "enabled." : "disabled."));
		}

		while (reloadDataKey.method_1436()) {
			reloadOreData(true);
		}

		while (openSearchKey.method_1436()) {
			if (client.field_1755 == null) {
				client.method_1507(new OreSearchScreen(this, loadSearchState()));
			}
		}
	}

	private void handleClientBlockBreak(class_638 world, class_746 player, net.minecraft.class_2338 pos, class_2680 state) {
		removeMarkersAt(world.method_27983().method_29177().toString(), pos);
	}

	private void extractAndDrawBox(WorldRenderContext context) {
		renderBox(context);
		if (buffer != null) {
			drawFilledThroughWalls(class_310.method_1551(), FILLED_THROUGH_WALLS);
		}
	}

	private void renderBox(WorldRenderContext context) {
		class_310 mc = class_310.method_1551();
		if (!overlayEnabled || mc.field_1724 == null || mc.field_1687 == null) {
			return;
		}

		class_243 camera = context.worldState().field_63082.field_63078;
		List<OreMarker> visibleMarkers = markerStore.getVisibleMarkers(mc.field_1687.method_27983().method_29177().toString(), camera);
		if (visibleMarkers.isEmpty()) {
			return;
		}

		class_4587 matrices = context.matrices();
		matrices.method_22903();
		matrices.method_22904(-camera.field_1352, -camera.field_1351, -camera.field_1350);

		if (buffer == null) {
			buffer = new class_287(
				ALLOCATOR,
				FILLED_THROUGH_WALLS.getVertexFormatMode(),
				FILLED_THROUGH_WALLS.getVertexFormat()
			);
		}

		Matrix4fc pose = matrices.method_23760().method_23761();
		for (OreMarker marker : visibleMarkers) {
			renderFilledBox(
				pose,
				buffer,
				marker.x(), marker.y(), marker.z(),
				marker.x() + 1.0f, marker.y() + 1.0f, marker.z() + 1.0f,
				marker.type().red(), marker.type().green(), marker.type().blue(), marker.type().alpha()
			);
		}

		matrices.method_22909();
	}

	public void reloadOreData(boolean announceToPlayer) {
		try {
			OreDataset dataset = dataLoader.load();
			applyDataset(dataset);

			if (announceToPlayer) {
				if (dataLoader.dataFileExists()) {
					showClientMessage("OreOverlay: loaded " + markerStore.markerCount() + " markers from " + dataLoader.getConfigPath() + ".");
				} else {
					showClientMessage("OreOverlay: no ore data file found at " + dataLoader.getConfigPath() + ". Rendering 0 markers.");
				}
			}

			OreOverlay.LOGGER.info("Loaded {} ore markers from {}", markerStore.markerCount(), dataLoader.getConfigPath());
		} catch (OreDataException exception) {
			showClientMessage("OreOverlay: reload failed: " + exception.getMessage());
			OreOverlay.LOGGER.warn("Failed to reload ore marker data", exception);
		}
	}

	private void showClientMessage(String message) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 != null) {
			client.field_1724.method_7353(class_2561.method_43470(message), false);
			return;
		}

		pendingMessages.addLast(message);
	}

	private void flushPendingMessages(class_310 client) {
		if (client.field_1724 == null) {
			return;
		}

		while (!pendingMessages.isEmpty()) {
			client.field_1724.method_7353(class_2561.method_43470(pendingMessages.removeFirst()), false);
		}
	}

	public SearchState loadSearchState() {
		return searchService.loadState();
	}

	public void saveSearchState(SearchState state) {
		searchService.saveState(state);
	}

	public CompletableFuture<SearchExecutionResult> searchMarkers(SearchState state, net.minecraft.class_2338 origin) {
		return searchService.search(state, origin);
	}

	public SearchExecutionResult clearSearchResults(SearchState state) throws OreDataException {
		SearchExecutionResult result = searchService.clearResults(state);
		applyDataset(result.dataset());
		showClientMessage("OreOverlay: cleared overlay results.");
		return result;
	}

	public int resetHiddenMarkers() throws OreDataException {
		int restoredMarkers = hiddenMarkerStateStore.reset(currentDataset);
		applyDataset(currentDataset);
		return restoredMarkers;
	}

	public int hiddenMarkerCount() {
		return Math.max(0, currentDataset.markerCount() - markerStore.markerCount());
	}

	public int clearQueryCache() throws OreSearchException {
		return searchService.clearQueryCache();
	}

	public void applySearchResult(SearchExecutionResult result, boolean announceToPlayer) {
		applyDataset(result.dataset());
		if (announceToPlayer) {
			String cacheSuffix = result.fromCache() ? " (cache)" : "";
			showClientMessage("OreOverlay: loaded " + result.markerCount() + " markers via local exact search" + cacheSuffix + ".");
		}
	}

	public void postClientMessage(String message) {
		showClientMessage(message);
	}

	private void applyDataset(OreDataset dataset) {
		currentDataset = dataset;
		markerStore = OreMarkerStore.fromDataset(hiddenMarkerStateStore.apply(dataset));
	}

	private void removeMarkersAt(String currentDimension, net.minecraft.class_2338 pos) {
		if (!currentDimension.equals(currentDataset.dimension()) || currentDataset.ores().isEmpty()) {
			return;
		}

		for (OreMarker marker : currentDataset.ores()) {
			if (marker.x() == pos.method_10263() && marker.y() == pos.method_10264() && marker.z() == pos.method_10260()) {
				try {
					hiddenMarkerStateStore.hide(currentDataset, pos);
					applyDataset(currentDataset);
				} catch (OreDataException exception) {
					OreOverlay.LOGGER.warn("Failed to persist hidden ore marker at {}", pos, exception);
				}
				return;
			}
		}
	}

	private void renderFilledBox(
		Matrix4fc positionMatrix,
		class_287 buffer,
		float minX, float minY, float minZ,
		float maxX, float maxY, float maxZ,
		float red, float green, float blue, float alpha
	) {
		buffer.method_22918(positionMatrix, minX, minY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, minY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, maxY, maxZ).method_22915(red, green, blue, alpha);

		buffer.method_22918(positionMatrix, maxX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, maxY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, minZ).method_22915(red, green, blue, alpha);

		buffer.method_22918(positionMatrix, minX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, minY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, maxY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, maxY, minZ).method_22915(red, green, blue, alpha);

		buffer.method_22918(positionMatrix, maxX, minY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, maxZ).method_22915(red, green, blue, alpha);

		buffer.method_22918(positionMatrix, minX, maxY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, maxY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, maxY, minZ).method_22915(red, green, blue, alpha);

		buffer.method_22918(positionMatrix, minX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, minY, minZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, maxX, minY, maxZ).method_22915(red, green, blue, alpha);
		buffer.method_22918(positionMatrix, minX, minY, maxZ).method_22915(red, green, blue, alpha);
	}

	private void drawFilledThroughWalls(class_310 client, RenderPipeline pipeline) {
		class_9801 builtBuffer = buffer.method_60800();
		class_9801.class_4574 drawParameters = builtBuffer.method_60822();
		VertexFormat format = drawParameters.comp_749();

		GpuBuffer vertices = upload(drawParameters, format, builtBuffer);
		draw(client, pipeline, builtBuffer, drawParameters, vertices, format);

		vertexBuffer.method_71121();
		buffer = null;
	}

	private GpuBuffer upload(class_9801.class_4574 drawParameters, VertexFormat format, class_9801 builtBuffer) {
		int vertexBufferSize = drawParameters.comp_750() * format.getVertexSize();

		if (vertexBuffer == null || vertexBuffer.method_71312() < vertexBufferSize) {
			if (vertexBuffer != null) {
				vertexBuffer.close();
			}

			vertexBuffer = new class_11285(
				() -> OreOverlay.MOD_ID + " box vertex buffer",
				GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
				vertexBufferSize
			);
		}

		CommandEncoder commandEncoder = RenderSystem.getDevice().createCommandEncoder();
		GpuBuffer.MappedView mappedView = commandEncoder.mapBuffer(vertexBuffer.method_71119().slice(), false, true);
		MemoryUtil.memCopy(builtBuffer.method_60818(), mappedView.data());
		mappedView.close();

		return vertexBuffer.method_71119();
	}

	private void draw(
		class_310 client,
		RenderPipeline pipeline,
		class_9801 builtBuffer,
		class_9801.class_4574 drawParameters,
		GpuBuffer vertices,
		VertexFormat format
	) {
		GpuBuffer indices;
		VertexFormat.class_5595 indexType;

		if (pipeline.getVertexFormatMode() == VertexFormat.class_5596.field_27382) {
			builtBuffer.method_60819(ALLOCATOR, RenderSystem.getProjectionType().method_65045());
			indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(builtBuffer.method_60821());
			indexType = builtBuffer.method_60822().comp_753();
		} else {
			RenderSystem.class_5590 shapeIndexBuffer =
				RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
			indices = shapeIndexBuffer.method_68274(drawParameters.comp_751());
			indexType = shapeIndexBuffer.method_31924();
		}

		GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
			.method_71106(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

		try (RenderPass renderPass = RenderSystem.getDevice()
			.createCommandEncoder()
			.createRenderPass(
				() -> OreOverlay.MOD_ID + " box render pass",
				client.method_1522().method_71639(),
				OptionalInt.empty(),
				client.method_1522().method_71640(),
				OptionalDouble.empty()
			)) {
			renderPass.setPipeline(pipeline);
			RenderSystem.bindDefaultUniforms(renderPass);
			renderPass.setUniform("DynamicTransforms", dynamicTransforms);
			renderPass.setVertexBuffer(0, vertices);
			renderPass.setIndexBuffer(indices, indexType);
			renderPass.drawIndexed(0, 0, drawParameters.comp_751(), 1);
		}

		builtBuffer.close();
	}
}
