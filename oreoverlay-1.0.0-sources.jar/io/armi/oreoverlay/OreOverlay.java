package io.armi.oreoverlay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class OreOverlay {
	public static final String MOD_ID = "oreoverlay";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private OreOverlay() {
	}
}
